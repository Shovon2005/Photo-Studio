from django.shortcuts import render,redirect
from django.http import HttpResponse
from store.models import *
# Create your views here.
def test(request):
    return HttpResponse('<h1>This is test page<h1>')
def index0(request):
    return render(request,'index0.html')
def index(request):
    return render(request,'index.html')
def index1(request):
    return render(request,'index1.html')
def index2(request):
    return render(request,'index2.html')
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def portfolio(request):
    return render(request,'portfolio.html')
def team(request):
    return render(request,'team.html')
def add(request):
    return render(request,'add.html')
def addcode(request):
    a=int(request.GET['a1'])
    b=int(request.GET['a2'])
    c=a+b
    return render(request,'add.html',{'x':c})
def calculator(request):
    return render(request,'calculator.html')
def cal(request):

    a=int(request.GET['a1'])
    b=int(request.GET['a2'])
    c=a+b
    d=a-b
    e=a*b
    f=a/b
    
    #return HttpResponse(c)
    return render(request,'calculator.html',{'w':c,'x':d,'y':e,'z':f})
def insert(request):
    return render(request,'insert.html')
def ins(request):
    u=user()
    u.name=request.GET['a1']
    u.email=request.GET['a2']
    u.password=request.GET['a3']
    u.phnno=request.GET['a4']
    u.save()
    return render(request,'insert.html')
def registration(request):
    return render(request,'registration.html')
def reg(request):
    u=user2()
    u.fullname=request.GET['fullname']
    u.username=request.GET['username']
    u.email=request.GET['email']
    u.password=request.GET['password']
    u.save()
    return render(request,'registration.html')

def regi(request):
    u=user3()
    u.fullname=request.GET['fullname']
    u.username=request.GET['username']
    u.email=request.GET['email']
    u.password=request.GET['password']
    u.save()
    return render(request,'about.html')

def show(request):
    a=user3.objects.all()
    return render(request,'show.html',{'x':a})
def dele(request,id):
    d=user3.objects.get(id=id)
    d.delete()
    return redirect("../show")

def edit(request,id):
    d=user3.objects.get(id=id)
    return render(request,'edit.html',{'x':d})

def edcode(request,id):
    d=user3.objects.get(id=id)
    d.fullname=request.GET['fullname']
    d.username=request.GET['username']
    d.email=request.GET['email']
    d.password=request.GET['password']
    d.save()
    return redirect('../show')

def login(request):
    return render(request,'login.html')
def log2(request):
    a=request.GET['username']
    b=request.GET['password']
    if user3.objects.filter(username=a,password=b):
        return render(request,'index.html')
    else:
        return render(request,'login.html')
    
def logout(request):
    return render(request,'logout.html')